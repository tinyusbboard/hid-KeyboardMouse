This is the source code package for USB HID keyboard tutorial by Joonas Pihlajamaa, published at Code and Life blog, http://codeandlife.com

The subfolder contain parts of V-USB library available at http://www.obdev.at/avrusb/ and its contents are copyrighted by their respective authors. My productions in the root folder are published under GNU GPL v3 (see License.txt).

I hope you have fun with this project!

- Joonas Pihlajamaa